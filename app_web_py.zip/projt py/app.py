from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_bcrypt import Bcrypt
from datetime import datetime, date
from functools import wraps
from werkzeug.utils import secure_filename
import json, secrets, re, os

app = Flask(__name__)
app.config['SECRET_KEY'] = secrets.token_hex(32)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///meetspace.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static', 'uploads')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

db  = SQLAlchemy(app)
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Connectez-vous pour accéder à cette page.'
login_manager.login_message_category = 'error'

# ─── HELPERS ──────────────────────────────────────────────────────────────────
def allowed_file(f): return '.' in f and f.rsplit('.',1)[1].lower() in ALLOWED_EXTENSIONS
def save_image(file):
    if file and allowed_file(file.filename):
        ext = file.filename.rsplit('.',1)[1].lower()
        name = secrets.token_hex(12) + '.' + ext
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], name))
        return 'uploads/' + name
    return None
def delete_image(path):
    if path and not path.startswith('http'):
        full = os.path.join(app.static_folder, path)
        if os.path.exists(full): os.remove(full)

# ─── MODELS ───────────────────────────────────────────────────────────────────
class User(UserMixin, db.Model):
    id               = db.Column(db.Integer, primary_key=True)
    nom              = db.Column(db.String(100), nullable=False)
    prenom           = db.Column(db.String(100), nullable=False)
    email            = db.Column(db.String(120), unique=True, nullable=False)
    password_hash    = db.Column(db.String(200), nullable=False)
    role             = db.Column(db.String(20), default='user')
    actif            = db.Column(db.Boolean, default=True)
    date_inscription = db.Column(db.DateTime, default=datetime.utcnow)
    reservations     = db.relationship('Reservation', backref='user', lazy=True)

    def set_password(self, p):  self.password_hash = bcrypt.generate_password_hash(p).decode()
    def check_password(self, p): return bcrypt.check_password_hash(self.password_hash, p)
    @property
    def nom_complet(self): return f"{self.prenom} {self.nom}"
    @property
    def is_admin(self): return self.role == 'admin'

class TypeSalle(db.Model):
    id          = db.Column(db.Integer, primary_key=True)
    nom         = db.Column(db.String(100), nullable=False, unique=True)
    description = db.Column(db.String(200))
    salles      = db.relationship('Salle', backref='type_salle', lazy=True)

class Salle(db.Model):
    id            = db.Column(db.Integer, primary_key=True)
    nom           = db.Column(db.String(100), nullable=False)
    capacite      = db.Column(db.Integer, nullable=False)
    description   = db.Column(db.Text)
    equipements   = db.Column(db.Text, default='[]')
    etage         = db.Column(db.String(50), default='')
    superficie    = db.Column(db.Integer, default=0)
    type_id       = db.Column(db.Integer, db.ForeignKey('type_salle.id'), nullable=True)
    image_path    = db.Column(db.String(300), default='')
    image_url     = db.Column(db.String(500), default='')
    image_color   = db.Column(db.String(20), default='#1a6b8a')
    active        = db.Column(db.Boolean, default=True)
    reservations  = db.relationship('Reservation', backref='salle', lazy=True, cascade='all, delete-orphan')

    def get_equipements(self):
        try: return json.loads(self.equipements) if self.equipements else []
        except: return []

    def set_equipements(self, lst): self.equipements = json.dumps(lst)

    def get_image(self):
        if self.image_path: return url_for('static', filename=self.image_path)
        if self.image_url:  return self.image_url
        return 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=700&q=80'

    def is_available(self, d, hd, hf):
        for r in Reservation.query.filter_by(salle_id=self.id, date_reservation=d, statut='confirmée').all():
            if not (hf <= r.heure_debut or hd >= r.heure_fin): return False
        return True

class Reservation(db.Model):
    id               = db.Column(db.Integer, primary_key=True)
    salle_id         = db.Column(db.Integer, db.ForeignKey('salle.id'), nullable=False)
    user_id          = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    date_reservation = db.Column(db.Date, nullable=False)
    heure_debut      = db.Column(db.String(5), nullable=False)
    heure_fin        = db.Column(db.String(5), nullable=False)
    motif            = db.Column(db.String(200), default='')
    nb_participants  = db.Column(db.Integer, default=1)
    statut           = db.Column(db.String(20), default='confirmée')
    date_creation    = db.Column(db.DateTime, default=datetime.utcnow)

# ─── DECORATORS ───────────────────────────────────────────────────────────────
def admin_required(f):
    @wraps(f)
    def dec(*a, **kw):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash('Accès réservé aux administrateurs.', 'error')
            return redirect(url_for('index'))
        return f(*a, **kw)
    return dec

@login_manager.user_loader
def load_user(uid): return User.query.get(int(uid))

# ─── AUTH ─────────────────────────────────────────────────────────────────────
@app.route('/inscription', methods=['GET','POST'])
def inscription():
    if current_user.is_authenticated: return redirect(url_for('index'))
    if request.method == 'POST':
        nom    = request.form['nom'].strip()
        prenom = request.form['prenom'].strip()
        email  = request.form['email'].strip().lower()
        pwd    = request.form['password']
        conf   = request.form['confirm_password']
        errors = []
        if len(nom)<2:   errors.append("Nom trop court (2 car. min).")
        if len(prenom)<2: errors.append("Prénom trop court (2 car. min).")
        if not re.match(r'^[\w\.-]+@[\w\.-]+\.\w+$', email): errors.append("Email invalide.")
        if User.query.filter_by(email=email).first(): errors.append("Email déjà utilisé.")
        if len(pwd)<8:   errors.append("Mot de passe : 8 car. minimum.")
        if pwd!=conf:    errors.append("Les mots de passe ne correspondent pas.")
        if errors:
            for e in errors: flash(e, 'error')
            return render_template('inscription.html', form_data=request.form)
        u = User(nom=nom, prenom=prenom, email=email)
        u.set_password(pwd)
        db.session.add(u); db.session.commit()
        login_user(u)
        flash(f'Bienvenue {u.prenom} !', 'success')
        return redirect(url_for('index'))
    return render_template('inscription.html', form_data={})

@app.route('/login', methods=['GET','POST'])
def login():
    if current_user.is_authenticated: return redirect(url_for('index'))
    if request.method == 'POST':
        email = request.form['email'].strip().lower()
        pwd   = request.form['password']
        u = User.query.filter_by(email=email).first()
        if u and u.check_password(pwd) and u.actif:
            login_user(u, remember=bool(request.form.get('remember')))
            flash(f'Bon retour, {u.prenom} !', 'success')
            return redirect(request.args.get('next') or url_for('index'))
        flash('Email ou mot de passe incorrect.', 'error')
    return render_template('login.html', form_data={})

@app.route('/logout')
@login_required
def logout():
    flash(f'À bientôt, {current_user.prenom} !', 'success')
    logout_user(); return redirect(url_for('index'))

# ─── PUBLIC ───────────────────────────────────────────────────────────────────
@app.route('/')
def index():
    salles = Salle.query.filter_by(active=True).all()
    today  = date.today()
    return render_template('index.html', salles=salles,
        reservations_today=Reservation.query.filter_by(date_reservation=today, statut='confirmée').count(),
        total_reservations=Reservation.query.filter_by(statut='confirmée').count(),
        total_users=User.query.count(), today=today)

@app.route('/salles')
def salles():
    types  = TypeSalle.query.all()
    filtre = request.args.get('type','')
    q      = Salle.query.filter_by(active=True)
    if filtre and filtre.isdigit():
        q = q.filter_by(type_id=int(filtre))
    return render_template('salles.html', salles=q.all(), types=types, filtre=filtre)

@app.route('/salle/<int:sid>')
def detail_salle(sid):
    salle = Salle.query.get_or_404(sid)
    today = date.today()
    reservations = Reservation.query.filter(
        Reservation.salle_id==sid,
        Reservation.date_reservation>=today,
        Reservation.statut=='confirmée'
    ).order_by(Reservation.date_reservation, Reservation.heure_debut).all()
    return render_template('detail_salle.html', salle=salle, reservations=reservations, today=today)

@app.route('/reserver/<int:sid>', methods=['GET','POST'])
@login_required
def reserver(sid):
    salle = Salle.query.get_or_404(sid)
    if request.method == 'POST':
        hd = request.form['heure_debut']
        hf = request.form['heure_fin']
        nb = int(request.form.get('nb_participants', 1))
        errors = []
        try:    d = datetime.strptime(request.form['date_reservation'], '%Y-%m-%d').date()
        except: errors.append("Date invalide."); d = None
        if d and d < date.today(): errors.append("Date dans le passé.")
        if hd >= hf: errors.append("L'heure de fin doit être après le début.")
        if nb > salle.capacite: errors.append(f"Capacité max : {salle.capacite} personnes.")
        if d and not errors and not salle.is_available(d, hd, hf):
            errors.append("Ce créneau est déjà réservé.")
        if errors:
            for e in errors: flash(e, 'error')
            return render_template('reserver.html', salle=salle, form_data=request.form, today=date.today().isoformat())
        r = Reservation(salle_id=sid, user_id=current_user.id, date_reservation=d,
                        heure_debut=hd, heure_fin=hf,
                        motif=request.form.get('motif','').strip(), nb_participants=nb)
        db.session.add(r); db.session.commit()
        flash(f'Réservation #{r.id} confirmée !', 'success')
        return redirect(url_for('confirmation', rid=r.id))
    return render_template('reserver.html', salle=salle, form_data={}, today=date.today().isoformat())

@app.route('/confirmation/<int:rid>')
@login_required
def confirmation(rid):
    r = Reservation.query.get_or_404(rid)
    if r.user_id != current_user.id and not current_user.is_admin:
        flash('Accès non autorisé.', 'error'); return redirect(url_for('index'))
    return render_template('confirmation.html', reservation=r)

@app.route('/mes-reservations')
@login_required
def mes_reservations():
    today = date.today()
    reservations = Reservation.query.filter_by(user_id=current_user.id)\
        .order_by(Reservation.date_reservation.desc()).all()
    return render_template('mes_reservations.html', reservations=reservations, today=today)

@app.route('/annuler/<int:rid>', methods=['POST'])
@login_required
def annuler(rid):
    r = Reservation.query.get_or_404(rid)
    if r.user_id != current_user.id and not current_user.is_admin:
        flash('Non autorisé.', 'error'); return redirect(url_for('mes_reservations'))
    if r.date_reservation >= date.today():
        r.statut = 'annulée'; db.session.commit(); flash('Réservation annulée.', 'success')
    else:
        flash("Impossible d'annuler une réservation passée.", 'error')
    return redirect(url_for('mes_reservations'))

@app.route('/profil', methods=['GET','POST'])
@login_required
def profil():
    if request.method == 'POST':
        current_user.nom    = request.form['nom'].strip()
        current_user.prenom = request.form['prenom'].strip()
        np = request.form.get('new_password','').strip()
        if np:
            if not current_user.check_password(request.form.get('current_password','')):
                flash('Mot de passe actuel incorrect.', 'error'); return redirect(url_for('profil'))
            if len(np) < 8:
                flash('Nouveau mot de passe trop court.', 'error'); return redirect(url_for('profil'))
            current_user.set_password(np)
        db.session.commit(); flash('Profil mis à jour.', 'success')
        return redirect(url_for('profil'))
    today = date.today()
    reservations = Reservation.query.filter_by(user_id=current_user.id)\
        .order_by(Reservation.date_reservation.desc()).limit(5).all()
    return render_template('profil.html', reservations=reservations, today=today)

# ─── ADMIN ─────────────────────────────────────────────────────────────────────
@app.route('/admin')
@login_required
@admin_required
def admin():
    return render_template('admin.html',
        salles=Salle.query.order_by(Salle.nom).all(),
        types=TypeSalle.query.order_by(TypeSalle.nom).all(),
        users=User.query.order_by(User.date_inscription.desc()).all(),
        reservations=Reservation.query.order_by(Reservation.date_reservation.desc()).limit(100).all(),
        today=date.today())

# ── Types de salle ─────────────────────────────────────────────────────────────
@app.route('/admin/type/ajouter', methods=['POST'])
@login_required
@admin_required
def ajouter_type():
    nom = request.form.get('nom','').strip()
    desc = request.form.get('description','').strip()
    if not nom:
        flash('Nom du type requis.', 'error'); return redirect(url_for('admin') + '#types')
    if TypeSalle.query.filter_by(nom=nom).first():
        flash('Ce type existe déjà.', 'error'); return redirect(url_for('admin') + '#types')
    db.session.add(TypeSalle(nom=nom, description=desc)); db.session.commit()
    flash(f'Type "{nom}" créé.', 'success'); return redirect(url_for('admin') + '#types')

@app.route('/admin/type/supprimer/<int:tid>', methods=['POST'])
@login_required
@admin_required
def supprimer_type(tid):
    t = TypeSalle.query.get_or_404(tid)
    if t.salles:
        flash(f'Impossible : {len(t.salles)} salle(s) utilisent ce type.', 'error')
        return redirect(url_for('admin') + '#types')
    db.session.delete(t); db.session.commit()
    flash(f'Type "{t.nom}" supprimé.', 'success'); return redirect(url_for('admin') + '#types')

# ── Salles CRUD ────────────────────────────────────────────────────────────────
@app.route('/admin/salle/ajouter', methods=['GET','POST'])
@login_required
@admin_required
def ajouter_salle():
    types = TypeSalle.query.order_by(TypeSalle.nom).all()
    if request.method == 'POST':
        nom       = request.form['nom'].strip()
        capacite  = request.form['capacite'].strip()
        if not nom or not capacite:
            flash('Nom et capacité sont obligatoires.', 'error')
            return render_template('ajouter_salle.html', types=types)
        equips    = request.form.getlist('equipements')
        eq_custom = [e.strip() for e in request.form.get('eq_custom','').split(',') if e.strip()]
        all_equips = equips + eq_custom

        image_path = ''
        image_url  = request.form.get('image_url','').strip()
        f = request.files.get('image_file')
        if f and f.filename:
            if not allowed_file(f.filename):
                flash('Format non supporté (PNG, JPG, GIF, WEBP).', 'error')
                return render_template('ajouter_salle.html', types=types)
            p = save_image(f)
            if p: image_path, image_url = p, ''

        type_id = request.form.get('type_id','').strip()
        s = Salle(
            nom=nom,
            capacite=int(capacite),
            description=request.form.get('description','').strip(),
            etage=request.form.get('etage','').strip(),
            superficie=int(request.form.get('superficie',0) or 0),
            type_id=int(type_id) if type_id else None,
            image_path=image_path, image_url=image_url,
            image_color=request.form.get('image_color','#1a6b8a')
        )
        s.set_equipements(all_equips)
        db.session.add(s); db.session.commit()
        flash(f'Salle "{nom}" créée avec succès.', 'success')
        return redirect(url_for('admin'))
    return render_template('ajouter_salle.html', types=types)

@app.route('/admin/salle/modifier/<int:sid>', methods=['GET','POST'])
@login_required
@admin_required
def modifier_salle(sid):
    salle = Salle.query.get_or_404(sid)
    types = TypeSalle.query.order_by(TypeSalle.nom).all()
    if request.method == 'POST':
        salle.nom         = request.form['nom'].strip()
        salle.capacite    = int(request.form['capacite'])
        salle.description = request.form.get('description','').strip()
        salle.etage       = request.form.get('etage','').strip()
        salle.superficie  = int(request.form.get('superficie',0) or 0)
        salle.image_color = request.form.get('image_color', salle.image_color)
        salle.active      = 'active' in request.form

        type_id = request.form.get('type_id','').strip()
        salle.type_id = int(type_id) if type_id else None

        equips    = request.form.getlist('equipements')
        eq_custom = [e.strip() for e in request.form.get('eq_custom','').split(',') if e.strip()]
        salle.set_equipements(equips + eq_custom)

        action = request.form.get('action_image','garder')
        f = request.files.get('image_file')
        if f and f.filename:
            if not allowed_file(f.filename):
                flash('Format non supporté.', 'error')
                return render_template('modifier_salle.html', salle=salle, types=types)
            delete_image(salle.image_path)
            p = save_image(f)
            if p: salle.image_path, salle.image_url = p, ''
        elif action == 'supprimer':
            delete_image(salle.image_path); salle.image_path = ''; salle.image_url = ''
        elif action == 'url':
            nu = request.form.get('image_url','').strip()
            if nu: delete_image(salle.image_path); salle.image_path = ''; salle.image_url = nu

        db.session.commit()
        flash(f'Salle "{salle.nom}" mise à jour.', 'success')
        return redirect(url_for('admin'))
    return render_template('modifier_salle.html', salle=salle, types=types)

@app.route('/admin/salle/supprimer/<int:sid>', methods=['POST'])
@login_required
@admin_required
def supprimer_salle(sid):
    s = Salle.query.get_or_404(sid)
    delete_image(s.image_path); db.session.delete(s); db.session.commit()
    flash(f'Salle "{s.nom}" supprimée.', 'success'); return redirect(url_for('admin'))

# ── Users ─────────────────────────────────────────────────────────────────────
@app.route('/admin/user/toggle/<int:uid>', methods=['POST'])
@login_required
@admin_required
def toggle_user(uid):
    u = User.query.get_or_404(uid)
    if u.id == current_user.id:
        flash('Impossible de modifier votre propre compte.', 'error'); return redirect(url_for('admin'))
    u.actif = not u.actif; db.session.commit()
    flash(f'Compte {"activé" if u.actif else "désactivé"}.', 'success'); return redirect(url_for('admin'))

@app.route('/admin/user/role/<int:uid>', methods=['POST'])
@login_required
@admin_required
def toggle_role(uid):
    u = User.query.get_or_404(uid)
    if u.id == current_user.id:
        flash('Impossible de modifier votre propre rôle.', 'error'); return redirect(url_for('admin'))
    u.role = 'admin' if u.role == 'user' else 'user'; db.session.commit()
    flash(f'Rôle modifié → {u.role}.', 'success'); return redirect(url_for('admin'))

@app.route('/admin/user/supprimer/<int:uid>', methods=['POST'])
@login_required
@admin_required
def supprimer_user(uid):
    u = User.query.get_or_404(uid)
    if u.id == current_user.id:
        flash('Impossible de supprimer votre propre compte.', 'error'); return redirect(url_for('admin'))
    Reservation.query.filter_by(user_id=uid).delete()
    db.session.delete(u); db.session.commit()
    flash(f'Utilisateur "{u.nom_complet}" supprimé.', 'success'); return redirect(url_for('admin'))

# ── Reservations admin ────────────────────────────────────────────────────────
@app.route('/admin/reservation/annuler/<int:rid>', methods=['POST'])
@login_required
@admin_required
def admin_annuler(rid):
    r = Reservation.query.get_or_404(rid)
    r.statut = 'annulée'; db.session.commit()
    flash(f'Réservation #{rid} annulée.', 'success'); return redirect(url_for('admin'))

@app.route('/api/disponibilite/<int:sid>')
def api_disponibilite(sid):
    salle = Salle.query.get_or_404(sid)
    try: d = datetime.strptime(request.args.get('date',''), '%Y-%m-%d').date()
    except: return jsonify({'error':'Date invalide'}), 400
    rs = Reservation.query.filter_by(salle_id=sid, date_reservation=d, statut='confirmée').all()
    return jsonify({'creneaux_occupes':[{'debut':r.heure_debut,'fin':r.heure_fin} for r in rs]})

# ─── INIT ──────────────────────────────────────────────────────────────────────
def init_db():
    with app.app_context():
        db.create_all()
        if TypeSalle.query.count() == 0:
            types = [
                TypeSalle(nom='Salle de réunion',   description='Pour les réunions d\'équipe et de travail'),
                TypeSalle(nom='Salle de conférence', description='Pour les grandes présentations et séminaires'),
                TypeSalle(nom='Salle de formation',  description='Pour les ateliers et formations'),
                TypeSalle(nom='Salle de direction',  description='Pour les réunions de direction confidentielles'),
            ]
            db.session.add_all(types); db.session.flush()
            print("✅ 4 types de salles créés")
        if User.query.count() == 0:
            a = User(nom='Admin', prenom='Super', email='admin@meetspace.com', role='admin')
            a.set_password('Admin1234!'); db.session.add(a)
            print("✅ Admin créé : admin@meetspace.com / Admin1234!")
        if Salle.query.count() == 0:
            t1 = TypeSalle.query.filter_by(nom='Salle de réunion').first()
            t2 = TypeSalle.query.filter_by(nom='Salle de conférence').first()
            t3 = TypeSalle.query.filter_by(nom='Salle de formation').first()
            t4 = TypeSalle.query.filter_by(nom='Salle de direction').first()
            demo = [
                Salle(nom='Salle Horizon', capacite=10, description='Salle moderne avec vue panoramique.',
                      etage='3ème étage', superficie=35, type_id=t1.id if t1 else None,
                      image_url='https://images.unsplash.com/photo-1497366216548-37526070297c?w=700&q=80',
                      image_color='#1a6b8a'),
                Salle(nom='Salle Zénith', capacite=20, description='Grande salle pour conférences.',
                      etage='1er étage', superficie=80, type_id=t2.id if t2 else None,
                      image_url='https://images.unsplash.com/photo-1531058020387-3be344556be6?w=700&q=80',
                      image_color='#6b3fa0'),
                Salle(nom='Salle Atelier', capacite=8, description='Espace créatif pour brainstormings.',
                      etage='2ème étage', superficie=25, type_id=t3.id if t3 else None,
                      image_url='https://images.unsplash.com/photo-1516321497487-e288fb19713f?w=700&q=80',
                      image_color='#c0392b'),
                Salle(nom='Salle Executive', capacite=6, description='Salle VIP confidentielle.',
                      etage='5ème étage', superficie=30, type_id=t4.id if t4 else None,
                      image_url='https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=700&q=80',
                      image_color='#27ae60'),
            ]
            for s in demo:
                s.set_equipements(['Projecteur HD','Tableau blanc','Visioconférence','WiFi','Climatisation'])
            db.session.add_all(demo); print("✅ 4 salles créées")
        db.session.commit()

if __name__ == '__main__':
    init_db()
    app.run(debug=True, port=5000)
